"use strict";
(() => {
var exports = {};
exports.id = 170;
exports.ids = [170];
exports.modules = {

/***/ 167:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 48:
/***/ ((module) => {

module.exports = require("cheerio");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("mysql");

/***/ }),

/***/ 423:
/***/ ((module) => {

module.exports = require("path");

/***/ }),

/***/ 147:
/***/ ((module) => {

module.exports = require("fs");

/***/ }),

/***/ 28:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {


const cheerio = __webpack_require__(48);
const { threej  } = __webpack_require__(710);
const chatDetailsFormat = {
    USERNAME: false,
    TITLE: "",
    DESCRIPTION: "",
    LINK: "",
    CTYPE: "",
    POSTCOUNT: false,
    VIEWS: false,
    SUBSCOUNT: false,
    PICSCOUNT: false,
    VIDEOSCOUNT: false,
    LINKSCOUNT: false,
    FILECOUNT: false
};
/**
 *
 * @param {string} username
 * @returns {object} Object containing chat details
 */ async function scrapChat(username) {
    const url = "https://telegram.me/s/" + username;
    const res = await threej.getHTML(url);
    var chatDetails = scrapChatDetailsAndViews(res.data, username, chatDetailsFormat);
    if (!chatDetails) {
        chatDetails = scrapChatDetails(res.data, username, chatDetailsFormat);
    }
    return chatDetails;
}
/**
 * scraps telegram chat details from provided dom element
 * @param {string} html
 * @returns {object|false} with chat details
 */ function scrapChatDetailsAndViews(html, username, chatDetailsFormat) {
    try {
        const $ = cheerio.load(html);
        let chatDetails = chatDetailsFormat;
        //total post loaded
        const length = $("body > main > div > section > div").length;
        if (!length) return false;
        //store postcount
        chatDetails.POSTCOUNT = $("body > main > div > section > div:last-child > div").attr("data-post").split("/")[1]++;
        let views = 0;
        let i = 1;
        // Avg post views & approx post count
        for(i; i <= 10; i++){
            let t = $("body > main > div > section > div:nth-child(" + (length - i) + ")").find("div.tgme_widget_message.text_not_supported_wrap.js-widget_message > div.tgme_widget_message_bubble > div.tgme_widget_message_footer.compact.js-message_footer > div > span.tgme_widget_message_views").text();
            if (t == "") break;
            views += threej.rkFormat(t) || 0;
        }
        chatDetails.VIEWS = Math.round(views / i) || views / i;
        //type
        chatDetails.CTYPE = "channel";
        //username
        chatDetails.USERNAME = username;
        //title
        chatDetails.TITLE = $("body > header > div > div.tgme_header_right_column > section > div > div.tgme_channel_info_header > div.tgme_channel_info_header_title_wrap > div.tgme_channel_info_header_title > span").text() || "";
        //description
        chatDetails.DESCRIPTION = $("body > header > div > div.tgme_header_right_column > section > div > div.tgme_channel_info_description").html() || "";
        //link
        chatDetails.LINK = "https://telegram.me/" + username;
        //chat counters
        $("body > header > div > div.tgme_header_right_column > section > div > div.tgme_channel_info_counters > div").each((k, v)=>{
            const type = $(v).find("span.counter_type").text();
            const value = $(v).find("span.counter_value").text();
            const key = /photos?/i.test(type) ? "PICSCOUNT" : /videos?/i.test(type) ? "VIDEOSCOUNT" : /files?/i.test(type) ? "FILECOUNT" : /links?/i.test(type) ? "LINKSCOUNT" : /subscribers?/i.test(type) ? "SUBSCOUNT" : "";
            chatDetails[key] = threej.rkFormat(value);
        });
        return chatDetails;
    } catch (error) {
        threej.logError(error);
        return false;
    }
}
/**
 * scraps telegram chat details from provided dom element
 * @param {string} html
 * @returns {object|false} with chat details
 */ function scrapChatDetails(html, username, chatDetailsFormat) {
    try {
        const $ = cheerio.load(html);
        let chatDetails = chatDetailsFormat;
        //username
        chatDetails.USERNAME = username;
        //title
        chatDetails.TITLE = $("body > div.tgme_page_wrap > div.tgme_body_wrap > div > div.tgme_page_title > span").text() || "";
        //description
        chatDetails.DESCRIPTION = $("body > div.tgme_page_wrap > div.tgme_body_wrap > div > div.tgme_page_description").html() || "";
        //link
        chatDetails.LINK = "https://telegram.me/" + username;
        //chat counters
        const match = $("body > div.tgme_page_wrap > div.tgme_body_wrap > div > div.tgme_page_extra").text().split(",")[0].replace(/ /g, "").match(/(\d+)([a-z]+)/);
        if (!match) {
            chatDetails.CTYPE = "bot";
        } else {
            chatDetails.CTYPE = match[2] == "members" ? "group" : match[2] == "subscribers" ? "channel" : "bot";
            if (chatDetails.CTYPE !== "bot") {
                chatDetails.SUBSCOUNT = match[1]++;
            }
        }
        if (chatDetails.TITLE === "" && chatDetails.TITLE === "") {
            return false;
        }
        return chatDetails;
    } catch (error) {
        threej.logError(error);
        return false;
    }
}
module.exports = {
    scrapChat
};


/***/ }),

/***/ 710:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {


const fs = __webpack_require__(147);
const path = __webpack_require__(423);
const axios = __webpack_require__(167);
const mysql = __webpack_require__(744);
/**
 * Helper class contains common usefull functions
 */ class Threej {
    constructor(){
        this.kformat = {
            t: 1e12,
            T: 1e12,
            b: 1e9,
            B: 1e9,
            m: 1e6,
            M: 1e6,
            k: 1e3,
            K: 1e3,
            "": 1
        };
        //create connection to mysql db
        this.db = mysql.createConnection({
            host: process.env.HOST,
            port: process.env.MYSQLPORT,
            user: process.env.MYSQLUSER,
            password: process.env.MYSQLPASSWORD,
            database: process.env.MYSQLDATABASE,
            connectTimeout: 4000,
            charset: "utf8mb4"
        });
    }
    async base64ToImg(base64String, fileLocation) {
        if (typeof base64String != "string" || typeof fileLocation != "string") throw new Error("Invalid parameters supplied.");
        const buffer = new Buffer.from(base64String, "base64");
        return await fs.writeFileSync(fileLocation, buffer);
    }
    async getHTML(url) {
        const res = await axios({
            url: url,
            headers: {
                accept: "text/html application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8",
                "accept-encoding": "gzip, deflate, br",
                "accept-language": "en-US;q=0.9"
            },
            gzip: true
        });
        return res;
    }
    /**
   *
   * @param {string} error
   */ logError(error) {
        if (error instanceof Error) {
            error = `[${new Date().toLocaleString()}] ${error.stack?.toString() || ""}\n\n`;
        } else if (typeof error == "string") {
            error = `[${new Date().toLocaleString()}] ${error}\n ${new Error().stack.toString()}\n\n`;
        } else return;
        try {
            fs.appendFileSync(path.resolve("errorByThreej.txt"), error);
        } catch (error) {
            fs.writeFileSync(path.resolve("errorByThreej.txt"), error);
        }
    }
    /**
   *
   * @param {string} str csv string
   * @param {char} delimiter
   * @returns {Array}
   */ parseCSV(str, delimiter = ",") {
        if (typeof str != "string") throw new Error("CSV string expected received " + typeof str);
        if (str.match("\\r\\n")) {
            str = str.replaceAll("\r\n", "\n");
        }
        const rows = str.split("\n");
        var parsed = [];
        rows.map((row)=>{
            parsed.push(row.split(delimiter));
        });
        return parsed;
    }
    /**
   * kFormatter - converts int to K M B format
   * @param {integer|double} data
   */ kFormat(number) {
        //check for numerical value
        if (!Math.round(number)) return false;
        for(const key in this.kformat){
            let div = number / this.kformat[key];
            if (div >= 1) {
                div = Math.round(div * 100) / 100;
                return (div + key).toUpperCase();
            }
        }
    }
    /**
   * Reverse kFormat
   * Converts K M B format to int
   *
   * @param {string} str Possible int
   * @return {int|false} int or false on failure
   */ rkFormat(str) {
        let lastChar = str.slice(-1);
        lastChar.match("[a-zA-Z]") ? "" : lastChar = "";
        const int = parseFloat(str) * this.kformat[lastChar];
        return int || false;
    }
    async query(sql, values) {
        const db = this.db;
        return new Promise((resolve, reject)=>{
            db.query(sql, values, (err, res)=>{
                if (err) {
                    reject(err);
                }
                resolve(res);
            });
        });
    }
    /**
   * Random integer between min & max inclusive
   * @param {integer} max
   * @param {integer} min
   * @returns
   */ randomInt(max, min = 0) {
        if (min > max) {
            max = min + max;
            min = max - min;
            max = max - min;
        }
        return Math.floor(Math.random() * (max - min + 1)) + min;
    }
    async saveRemoteFile(url, storagePath, filename = "F" + Date.now()) {
        try {
            const writer = fs.createWriteStream(path.resolve(storagePath, filename + path.extname(url)));
            const response = await axios.get(url, {
                responseType: "stream"
            });
            response.data.pipe(writer);
            return new Promise((resolve, reject)=>{
                writer.on("finish", resolve(storagePath + filename + path.extname(url)));
                writer.on("error", reject);
            });
        } catch (error) {
            this.logError(error);
        }
    }
    async sleep(ms) {
        new Promise((r)=>setTimeout(r, ms));
    }
    toCamelCase(text) {
        if (typeof text != "string") return text;
        var str = text.toLowerCase();
        return str.replace(/\b\w/g, (match)=>{
            return match.toUpperCase();
        });
    }
}
const threej = new Threej();
module.exports = {
    Threej,
    threej
};


/***/ }),

/***/ 953:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ handler)
});

// EXTERNAL MODULE: ./lib/scrapper.js
var scrapper = __webpack_require__(28);
// EXTERNAL MODULE: ./lib/threej.js
var threej = __webpack_require__(710);
;// CONCATENATED MODULE: ./lib/getchat.js


async function getChat(category, language, limit = 20) {
    const chats = await threej.threej.query("SELECT CID, USERNAME, POSTCOUNT, CUPDATE, TITLE, DESCRIPTION, PHOTO, SUBSCOUNT, PICSCOUNT, VIDEOSCOUNT, LINKSCOUNT, FILECOUNT FROM ?? WHERE CATEGORY LIKE ? AND CLANGUAGE LIKE ? AND USERNAME IS NOT NULL AND CTYPE = 'channel' ORDER BY SUBSCOUNT DESC LIMIT ?", [
        process.env.CHATSTABLE,
        category,
        language || "en",
        limit
    ]);
    let result = [];
    chats.map(async (e)=>{
        //update chat details if 4hr passed from last update
        if (e.CUPDATE < Math.round(Date.now() / 1000 - 14400)) {
            e.POSTCOUNT = await updateChat(e.CID, e.USERNAME);
        }
        if (e.POSTCOUNT != 0) {
            result.push({
                username: e.USERNAME,
                lastPostId: e.POSTCOUNT,
                title: e.TITLE,
                description: e.DESCRIPTION,
                subscribers: e.SUBSCOUNT,
                images: e.PICSCOUNT,
                videos: e.VIDEOSCOUNT,
                links: e.LINKSCOUNT,
                files: e.FILECOUNT,
                photo: e.PHOTO
            });
        }
    });
    return result;
}
//update db with new chat details
async function updateChat(chatId, username) {
    const chatdetails = await (0,scrapper.scrapChat)(username);
    if (chatdetails.POSTCOUNT == 0) {
        threej.threej.query("DELETE FROM ?? WHERE CID = ?", [
            process.env.CHATSTABLE,
            chatId
        ]);
    }
    const sql = `UPDATE ?? SET 
        TITLE = COALESCE(?, TITLE), 
        DESCRIPTION = COALESCE(?, DESCRIPTION), 
        SUBSCOUNT = COALESCE(?, SUBSCOUNT), 
        CUPDATE = COALESCE(?, CUPDATE), 
        VIEWS = COALESCE(?, VIEWS), 
        PICSCOUNT = COALESCE(?, PICSCOUNT), 
        VIDEOSCOUNT = COALESCE(?, VIDEOSCOUNT), 
        LINKSCOUNT = COALESCE(?, LINKSCOUNT), 
        POSTCOUNT = COALESCE(?, POSTCOUNT), 
        FILECOUNT = COALESCE(?, FILECOUNT)
        WHERE CID = ?`;
    const values = [
        process.env.CHATSTABLE,
        chatdetails.TITLE || null,
        chatdetails.DESCRIPTION || null,
        chatdetails.SUBSCOUNT || null,
        Math.round(Date.now() / 1000),
        chatdetails.VIEWS || null,
        chatdetails.PICSCOUNT || null,
        chatdetails.VIDEOSCOUNT || null,
        chatdetails.LINKSCOUNT || null,
        chatdetails.POSTCOUNT || null,
        chatdetails.FILECOUNT || null,
        chatId
    ];
    try {
        await threej.threej.query(sql, values);
        return chatdetails.POSTCOUNT;
    } catch (error) {
        threej.threej.logError(error);
        return false;
    }
}

;// CONCATENATED MODULE: ./pages/api/chat.js

async function handler(req, res) {
    const chats = await getChat(req.query.category || 28, req.query.language || "en", 20);
    res.status(200).json(chats);
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(953));
module.exports = __webpack_exports__;

})();